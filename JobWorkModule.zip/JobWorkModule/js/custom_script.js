$(function () {
  $(".my_picker").datepicker({ 
        autoclose: true, 
    startView: 2
  }).datepicker('update', new Date());;
});
