/*-- Sidebar --*/
$('.sidebar-toggle').on('click', function() {
    if( $(window).width() < 992) {
        // use float sidebar
        if(!$('.side-bar').hasClass('sidebar-collapse')) {
            $('.side-bar').addClass('sidebar-collapse');
            $('.dashboard-container').addClass('right-wrapper-expand');

        } else {
            $('.side-bar').removeClass('sidebar-collapse');
            $('.dashboard-container').removeClass('right-wrapper-expand');
        }
    } else {
        // use collapsed sidebar
        if(!$('.side-bar').hasClass('sidebar-collapse')) {
            $('.side-bar').addClass('sidebar-collapse');
            $('.dashboard-container').addClass('right-wrapper-expand');
            $('.sidenavbar-ul li a span').fadeOut(50);
            $('.userinfo-basic').fadeOut(50);
        } else {
            $('.side-bar').removeClass('sidebar-collapse');
            $('.dashboard-container').removeClass('right-wrapper-expand');
            
            setTimeout(function () {      
                $('.userinfo-basic').fadeIn(600);
                $('.sidenavbar-ul li a span').fadeIn(600);       
       }, 500);
        }
    }
}); 

/* -- --*/



	// set minimum height for content wrapper
	$(window).bind("load resize scroll", function () {
        calculateContentMinHeight();
	});

	function calculateContentMinHeight() {
        var rgt_wraper = $('.side-bar').height() + 30;
        $('.right-wrapper').css('min-height', rgt_wraper);
	}


    /* Chat Tab */


    $(document).ready(function(){
	
        $('.tab-link').click(function(){
            
            var tab_id = $(this).attr('data-tab');

            $('.tab-link').removeClass('current');
            $('.tab-content').removeClass('current');

            $(this).addClass('current');
            $("#"+tab_id).addClass('current');
        })

        //Chat height 

        resizeContent();

			$(window).resize(function() {
				resizeContent();
			});
		

		function resizeContent() {
			
			$height = $('.right-wrapper').height();
			
			
			$height2 = $('.right-wrapper').height() - 70;
			$('.chat-left').height($height2);
			
			$height3 = $('.right-wrapper').height() - 220;
			$('.contact-chatlist').height($height3);
			
			
		}




    });


/* Chat Tab */


/* Search box for mobile */

    $(document).ready(function(){
        $('.search-icon-mobile').click(function(){
            $('.header-search').fadeToggle();

        });
    });



    


/* Search box for mobile */